<% "---" %>
tags:
  - "#My/Daily"
  - "#My/Journal"
cssclasses:
aliases:
Location: 
Date-Added: "[[{{date:YYYY-MM-DD}}]]"
Week: "[[{{date:gggg-[W]ww}}]]"
Quarter:
  - "[[Q{{date: Q}} - {{date:YYYY}}]]"
Month:
  - "[[{{date: MMMM YYYY}}]]"
Year:
  - "[[{{date: YYYY}}]]"
DailyHighlight: 
DailyInterest: 
DailyEnergy: 
DailyProductivity: 
DailyGratitude: 
DailyIdea: 
DailyTomorrow:
DailyOverallMood:
<%*
  const modalForm = app.plugins.plugins.modalforms.api;
  const result = await modalForm.openForm("DailyJournal");
  tR += result.asFrontmatterString();
-%>
<% "---" %>

>[!info]- Meta Details
> Date: [[<% tp.date.now("DD-MM-YY") %>]]
> Week: [[<% tp.date.now("gggg-[W]ww") %>]]
> Month: [[<% tp.date.now("MMMM YYYY") %>]]
> Quarter: [[Q<% tp.date.now("Q") %> - <% tp.date.now("YYYY") %>]]
> Year: [[<% tp.date.now("YYYY") %>]]

<%*
const files = app.vault.getFiles()
const random = Math.floor(Math.random() * (files.length - 1))
const randomNote = files[random]
-%>

>[!summary] Today's Random Note📝
[[<% randomNote.basename %>]]

### 🗓️Daily Reflection Notes

##### What did you Learn or Work on? `INPUT[textArea:DailyLearning]` 
##### What is your Focus Today? `INPUT[textArea:DailyFocus]`
##### What is your Overall Mood? `INPUT[inlineSelect(option(Select), option(😠Angry), option(😟Anxious), option(😐Bored), option(🙂Content), option(🎉Excited), option(😤Frustrated), option(😃Happy), option(😔Lonely), option(😌Relaxed), option(😢Sad), option(😴Tired)):DailyOverallMood]`

---

##### What's on your mind?
`INPUT[textArea:DailyBrainDump]`

---

##### What caught your interest today?
`INPUT[textArea:DailyInterest]`

---
##### What drained you of energy?
`INPUT[textArea:DailyEnergy]`

---
##### What are 3 things I'm grateful for?
`INPUT[inlineList:DailyGratitude]`

---
##### Did you discover any new ideas?
`INPUT[inlineList:DailyIdea]`

---
##### How do I plan to have a better tomorrow?
`INPUT[textArea:DailyTomorrow]`

---

## Files Created Today
```dataview
TABLE without ID 
  file.link AS "File",
  dateformat(file.ctime, "yyyy-MM-dd") AS "Created"
FROM ""
WHERE file.ctime >= date([[<% tp.date.now('YYYY-MM-DD') %>]]) AND file.ctime < date([[<% tp.date.now('YYYY-MM-DD') %>]]) + dur(1 day)
SORT file.ctime DESC
LIMIT 10
```
## Files Modified Today
```dataview
TABLE without ID
  file.link AS "File",
  dateformat(file.mtime, "yyyy-MM-dd") AS "Modified"
FROM ""
WHERE file.mtime >= date([[<% tp.date.now('YYYY-MM-DD') %>]]) AND file.mtime < date([[<% tp.date.now('YYYY-MM-DD') %>]]) + dur(1 day)
SORT file.mtime DESC
LIMIT 30
```

>[!related] Navigation 🧭
>[[<% tp.date.now("DD-MM-YY", -1) %>|⬅️ Yesterday]] | [[<% tp.date.now("DD-MM-YY", 1) %> |  Tomorrow ➡️]]

>[!example]- Action Items
> - [[Daily Reminders for 2025]]
>  - [[My Focus👁️]]


<%*
const view = app.workspace.activeLeaf.getViewState()
view.state.mode = 'source'
view.state.source = false
app.workspace.activeLeaf.setViewState(view)
%>