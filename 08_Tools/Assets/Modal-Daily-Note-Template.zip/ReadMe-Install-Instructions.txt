### How to Apply this Daily Note Template to your Vault?

1. Extract the Contents of the ZIP File "Modal-Daily-Note-Template.zip"
2. Add the "Modal Form - Daily Note Journal Template.md" to your Template Directory Folder
3. Install Community Plugins Dataview, Templater, Periodic Notes, Calendar and Modal Forms.
4. Set your Periodic Daily Note Setting or Daily Note Settings depending on what you're using.
5. Open "Import-Daily-Modal-Form-Data.txt" and Select All the Text then Copy that JSON data
6. In Obsidina, CTRL+P > Select Modal Forms: Manage Forms
7. Select Import Form, Paste the JSON data you copied, then select the import button
9. This is optional but you can also trigger this with QuickAdd Template Choice
- File Name Format = {{DATE:DD-MM-YY}}
- Choose your Daily Journal Folder as Location
- Open Note once created

