---
tags:
  - "#Obsidian/Plugins/Dataview"
  - "#Obsidian"
cssclasses: 
aliases: 
Date-Added: "[[2024-11-06]]"
Week: "[[2024-W45]]"
Quarter:
  - "[[Q4 - 2024]]"
Month:
  - "[[November 2024]]"
Year:
  - "[[2024]]"
Category:
  - Obsidian
Notes: Obsidian Built In Data Reference
Source:
---

>[!info]- Meta Details
> Date: [[06-11-24]]
> Week: [[2024-W45]]
> Month: [[November 2024]]
> Quarter: [[Q4 - 2024]]
> Year: [[2024]]

```meta-bind-embed
[[Metabind Dataview Query Buttons]]
```
## Summary

| Field Name                | Description                                                                                                                  |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------|
| file.name                 | The file name as seen in Obsidian's sidebar.                                                                                |
| file.folder               | The path of the folder this file belongs to.                                                                                 |
| file.path                 | The full file path, including the file's name.                                                                              |
| file.ext                  | The extension of the file type; generally md.                                                                               |
| file.link                 | A link to the file.                                                                                                         |
| file.size                 | The size (in bytes) of the file.                                                                                            |
| file.ctime with Time      | The date that the file was created.                                                                                         |
| file.cday                 | The date that the file was created.                                                                                         |
| file.mtime with Time      | The date that the file was last modified.                                                                                   |
| file.mday                 | The date that the file was last modified.                                                                                   |
| file.tags                 | A list of all unique tags in the note. Subtags are broken down by each level, so #Tag/1/A will be stored in the list as [#Tag, #Tag/1, #Tag/1/A]. |
| file.etags                | A list of all explicit tags in the note; unlike file.tags, does not break subtags down, i.e. [#Tag/1/A]                    |
| file.inlinks              | A list of all incoming links to this file, meaning all files that contain a link to this file.                             |
| file.outlinks             | A list of all outgoing links from this file, meaning all links the file contains.                                           |
| file.aliases              | A list of all aliases for the note as defined via the YAML frontmatter.                                                    |
| file.tasks                | A list of all tasks (i.e., |[ ] some task) in this file.                                                                   |
| file.lists                | A list of all list elements in the file (including tasks); these elements are effectively tasks and can be rendered in task views. |
| file.frontmatter          | Contains the raw values of all frontmatter in the form of key |value text values; mainly useful for checking raw frontmatter values or dynamically listing frontmatter keys. |
| file.day                  | Only available if the file has a date inside its file name (of form yyyy-mm-dd or yyyymmdd), or has a Date field/inline field. |
| file.starred              | If this file has been starred via the Obsidian Core Plugin “Starred Files”.                                               |


### When to use?


## Example









