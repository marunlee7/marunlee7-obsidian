---
Date-Added: 2024-10-03
tags:
  - "#Obsidian/Plugins/Dataview"
  - "#Obsidian"
Category:
  - Obsidian
Notes: From Dataview Example Vault
Source:
  - https://github.com/s-blu/obsidian_dataview_example_vault?tab=readme-ov-file
aliases:
---

>[!info]- Meta Details
> Date: [[03-10-24]]
> Month: [[October 2024]]
> Quarter: [[Q4 - 2024]]
> Year: [[2024]]

```meta-bind-embed
[[Metabind Dataview Query Buttons]]
```

```table-of-contents
title: 
style: nestedList # TOC style (nestedList|nestedOrderedList|inlineFirstLevel)
minLevel: 0 # Include headings from the specified level
maxLevel: 0 # Include headings up to the specified level
includeLinks: true # Make headings clickable
debugInConsole: false # Print debug info in Obsidian console
```

## Summary

The Basics of Dataview are listed here

## Basic Table Queries

##### 1. Show pages from a folder as table
```markdown
 TABLE
FROM "00 NoteLab"
LIMIT 2
```

*Result*
```dataview
TABLE
FROM "00 NoteLab"
LIMIT 2
```

---
##### 2. Show pages from a tag  as table
```markdown
TABLE
FROM #Books 
LIMIT 2
```

*Example*
```dataview
TABLE
FROM #Book
LIMIT 2
```

---
##### 3. Combine multiple tags
```markdown
TABLE
FROM #Book OR #Source/Books 
LIMIT 2
```

*Example*
```dataview
TABLE
FROM #Book OR #Source/Books 
LIMIT 2
```

---
##### 4. Combine multiple folders
```markdown
TABLE
FROM "00 NoteLab" OR "02 Cards"
LIMIT 2
```

*Example*
```dataview
TABLE
FROM "00 NoteLab" OR "02 Cards"
LIMIT 2
```

---
##### 5. Combine tags and folders
```markdown
TABLE
FROM "00 NoteLab" AND #🌱
LIMIT 2
```

*Example*
```dataview
TABLE
FROM "00 NoteLab" AND #🌱
LIMIT 2
```

---

## Variants

##### 1. Show pages from a certain author

```markdown
TABLE
FROM #Book  
WHERE Author = "Alden Mills" 
OR Author = [[Alden Mills]]
```

*Example*
```dataview
TABLE
FROM #Book
WHERE Author = "Alden Mills" 
OR Author = [[Alden Mills]]
```

##### 2. Show only meta data information and no file link

```markdown
TABLE WITHOUT ID file.name as "Title", Category, Topics, Author 
FROM "+ Personal Development/01 Authors"
WHERE Category
```

```dataview
TABLE WITHOUT ID file.name as "Title", Category, Topics, Author 
FROM "+ Personal Development/01 Authors"
WHERE Category
LIMIT 3
```











