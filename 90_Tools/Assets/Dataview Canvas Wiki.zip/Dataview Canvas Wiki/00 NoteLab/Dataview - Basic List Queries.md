---
Date-Added: 2024-11-06
tags:
  - "#Obsidian/Plugins/Dataview"
  - "#Obsidian"
Category:
  - Obsidian
Notes: From Dataview Example Vault
Source:
  - https://github.com/s-blu/obsidian_dataview_example_vault?tab=readme-ov-file
aliases:
---

>[!info]- Meta Details
> Date: [[03-10-24]]
> Month: [[October 2024]]
> Quarter: [[Q4 - 2024]]
> Year: [[2024]]

```meta-bind-embed
[[Metabind Dataview Query Buttons]]
```

```table-of-contents
title: 
style: nestedList # TOC style (nestedList|nestedOrderedList|inlineFirstLevel)
minLevel: 0 # Include headings from the specified level
maxLevel: 0 # Include headings up to the specified level
includeLinks: true # Make headings clickable
debugInConsole: false # Print debug info in Obsidian console
```

## Summary

The Basics of Dataview are listed here

## Basic List Queries

##### 1.  List pages from a folder
```markdown
 LIST
FROM "00 NoteLab"
LIMIT 2
```

*Result*
```dataview
LIST
FROM "00 NoteLab"
LIMIT 2
```

---
##### 2. List pages from a tag
```markdown
LIST
FROM #Books 
LIMIT 2
```

*Example*
```dataview
LIST
FROM #Book
LIMIT 2
```

---
##### 3. Combine multiple tags
```markdown
LIST
FROM #Book OR #Source/Books 
LIMIT 2
```

*Example*
```dataview
LIST
FROM #Book OR #Source/Books 
LIMIT 2
```

---
##### 4. Combine multiple folders
```markdown
LIST
FROM "00 NoteLab" OR "02 Cards"
LIMIT 2
```

*Example*
```dataview
TABLE
FROM "00 NoteLab" OR "02 Cards"
LIMIT 2
```

---
##### 5. Combine tags and folders
```markdown
LIST
FROM "00 NoteLab" AND #🌱
LIMIT 2
```

*Example*
```dataview
LIST
FROM "00 NoteLab" AND #🌱
LIMIT 2
```

---


```dataview
LIST rows.file.link
FROM "04 VAULT/Books"
GROUP BY Author
```








