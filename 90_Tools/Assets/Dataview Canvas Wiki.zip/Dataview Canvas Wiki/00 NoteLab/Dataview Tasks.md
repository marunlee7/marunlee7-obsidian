---
tags:
  - Tasks
Due: 2024-11-18
---

- [ ] Dataview Video 🛫 2024-11-18 📅 2024-11-24
- [x] Example of a Completed Task ✅ 2024-11-18'
- [x] Dataview Key Query Components ✅ 2024-11-22
- [ ] Dataview Key Features
- [ ] How to Apply a Dataview Query

