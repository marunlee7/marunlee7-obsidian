---
cssclasses:
---

`BUTTON[Home]` `BUTTON[NoteLab]`

>[!info]
>This is your default Inbox for your [[Fleeting Notes]].
>A place to store your notes when you capture them.
>Learn [[+ About NoteLab ℹ️]]

## Base

![[00 NoteLab.base]]
```meta-bind-embed
[[MetaBind Main Navigation]]
```

---
## Dataview

```dataview
table file.ctime as Date from "00 NoteLab"
sort file.name
```




