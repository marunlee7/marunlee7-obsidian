`BUTTON[Home]`

>[!quote] What is Bases?
>Bases is a [core plugin](https://help.obsidian.md/plugins) that lets you turn any set of notes into a powerful database. With bases you can organize everything from projects to travel plans, reading lists, and more.

>[!tip]
>To get access to Bases as of *01/06/2025* you need to be a [Obsidian Catalyst](https://help.obsidian.md/catalyst)Insider, Supporter or VIP running Obsidian 1.9.0 or above
>

- To create your first base hit CTRL + P and type "Bases"
- Select "Create New Base" or "Insert Base"
- Both options create the Base in your Default Note Location (which for now is a little annoying but may change in the future.)
### Example

Below is an example of an Embedded Base listing all the Bases/Files in the 
"03 Spaces/Bases" folder;

![[Bases Index.base]]
```meta-bind-embed
[[MetaBind Main Navigation]]
```

```
# To embed a base we use the Syntax below
![[Bases Index.base]]
```

At the moment you have to manually sort your base files, I hope this changes in the future.