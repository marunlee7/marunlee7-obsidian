---
cssclasses:
---

`BUTTON[Home]` `BUTTON[Spaces]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```
>[!info] Info
>⚗️Distil your ideas 💡here and get ready to show your work using notes 📝 from your Vault. [[+ About Spaces ℹ️]]

## Base
![[03 Spaces.base#Spaces]]

---
## Dataview

```dataview
TABLE
file.ctime as "Date Created"
FROM "03 Spaces"
SORT file.name DESC
```
