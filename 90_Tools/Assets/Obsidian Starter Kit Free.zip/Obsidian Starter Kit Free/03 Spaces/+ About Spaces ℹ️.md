
⬆️:: [[+ START HERE]]

 **Spaces are a place for you to work on things that you're interested in.**

>[!tip] 
>⚗️Distil your ideas 💡here and get ready to show your work using notes 📝 from your Vault.

#### A few ideas of what to store in here could be:

1. Distilled Notes
2. Excalidraw Drawings
3. Music
4. Canvas Mind Maps
5. Courses and Learning
6. Websites, Blogs, Online Content
7. Knowledge Wikis


