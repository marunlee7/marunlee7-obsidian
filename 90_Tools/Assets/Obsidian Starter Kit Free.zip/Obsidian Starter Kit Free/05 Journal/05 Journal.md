
`BUTTON[Home]` `BUTTON[Journal]`

>[!info] Info
>A personal space where you can store your Daily, Weekly, Monthly, Quarterly, Yearly Journal entries. Reviews, Thoughts, Goal Outcomes and Values.

## Base
![[05 Journal.base#Journal]]

---
## Dataview
```meta-bind-embed
[[MetaBind Main Navigation]]
```

```dataview
TABLE
file.ctime as "Date Created"
FROM "05 Journal"
SORT file.name DESC
```

---

