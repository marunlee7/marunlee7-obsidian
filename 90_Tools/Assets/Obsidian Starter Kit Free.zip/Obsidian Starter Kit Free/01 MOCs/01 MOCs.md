---
cssclasses:
---

`BUTTON[Home]` `BUTTON[MOCs]`

>[!info] Info
>Map of Contents are helpful when you need an index page to capture information about a particular topic. Think of this like a Central Location. Read more [[+ About MOCs ℹ️]]
## Base
![[01 MOCs.base#Map of Contents]]

---
## Dataview
```meta-bind-embed
[[MetaBind Main Navigation]]
```

```dataview
TABLE
file.ctime as "Date Created"
FROM "01 MOCs"
SORT file.name DESC
```
