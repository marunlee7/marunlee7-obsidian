
`BUTTON[Home]` `BUTTON[Vault]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```
>[!info] Info
>This will be [Literature Notes](app://obsidian.md/Literature%20Notes) captured from consuming information. [[+ About Vaults ℹ️]]

## Base
![[04 Vault Index.base]]

---
## Dataview

```dataview
TABLE
file.ctime as "Date Created",
file.mtime as "Date Modified"
FROM "04 Vault"
SORT file.name DESC
```

