
```meta-bind-button
label: "🏠HOME"
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Home"
style: default
actions:
  - type: open
    link: "[[+ START HERE]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About NoteLab
icon: ""
hidden: true
class: ""
tooltip: ""
id: "NoteLab"
style: default
actions:
  - type: open
    link: "[[+ About NoteLab ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About MOCs
icon: ""
hidden: true
class: ""
tooltip: ""
id: "MOCs"
style: default
actions:
  - type: open
    link: "[[+ About MOCs ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About Cards
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Cards"
style: default
actions:
  - type: open
    link: "[[+ About Cards ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About Spaces
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Spaces"
style: default
actions:
  - type: open
    link: "[[+ About Spaces ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About Vault
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Vault"
style: default
actions:
  - type: open
    link: "[[+ About Vaults ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About Journal
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Journal"
style: default
actions:
  - type: open
    link: "[[+ About Journal ℹ️]]"
    newTab: false

```

```meta-bind-button
label: ℹ️ About ToolKit
icon: ""
hidden: true
class: ""
tooltip: ""
id: "ToolKit"
style: default
actions:
  - type: open
    link: "[[+ About ToolKitℹ️]]"
    newTab: false

```

```meta-bind-button
label: 📥Inbox
icon: ""
hidden: true
class: ""
tooltip: ""
id: "Inbox"
style: default
actions:
  - type: open
    link: "[[Inbox 🗺️]]"
    newTab: false

```