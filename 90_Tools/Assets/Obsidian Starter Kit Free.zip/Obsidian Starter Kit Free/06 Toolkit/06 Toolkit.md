
`BUTTON[Home]` `BUTTON[ToolKit]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```

>[!info] Info
>A personal space where you can store your Daily, Weekly, Monthly, Quarterly, Yearly Journal entries. Reviews, Thoughts, Goal Outcomes and Values.

## Base
![[06 Toolkit.base]]

---
## Dataview

```dataview
TABLE
file.ctime as "Date Created"
FROM "06 Toolkit"
SORT file.name DESC
```

---

