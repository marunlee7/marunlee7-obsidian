---
tags:
  - "#People"
  - "#👤️"
Date-Created: 
Category:
  - People
Topics: 
---

`BUTTON[Home]` `BUTTON[Cards]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```


## Notes
- 
## Known for
- 
## Links
- 
