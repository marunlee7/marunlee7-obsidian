---
Date-Created:
tags:
  - "#Fleeting-Note"
  - "#🌱"
Type: "[[Fleeting]]"
Connected:
---

`BUTTON[Home]` `BUTTON[NoteLab]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```

## Note