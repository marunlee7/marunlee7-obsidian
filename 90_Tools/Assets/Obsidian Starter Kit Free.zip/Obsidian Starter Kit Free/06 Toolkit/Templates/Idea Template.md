---
Status:
  - In Progress
tags:
  - "#My/Idea"
  - "#Idea"
  - "#💡"
Date-Created: 
Category:
  - Ideas
Topics: 
Summary: 
Source:
---

`BUTTON[Home]` `BUTTON[Cards]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```

## Idea

