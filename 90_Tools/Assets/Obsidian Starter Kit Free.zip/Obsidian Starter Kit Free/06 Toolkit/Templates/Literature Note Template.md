---
Date-Created:
tags:
  - "#🌱"
  - "#Literature Note"
Type: "[[Literature]]"
Connected:
---

`BUTTON[Home]` `BUTTON[Vault]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```

## Note