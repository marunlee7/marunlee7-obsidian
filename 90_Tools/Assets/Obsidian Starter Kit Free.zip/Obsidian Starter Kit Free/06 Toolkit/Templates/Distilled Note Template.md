---
Date-Created: 
tags:
  - "#🌱"
  - "#Distilled-Note"
  - "#⚗️"
Type: "[[Distilled]]"
Connected:
---

`BUTTON[Home]` `BUTTON[Spaces]`

```meta-bind-embed
[[MetaBind Main Navigation]]
```

## Note