---
cssclasses:
---

`BUTTON[Home]` `BUTTON[Cards]`

>[!info] Info
>Think of it like a Post It Note with everything you have written down which lives in a folder inside your vault [[+ About Cards ℹ️]]
## Base
![[02 Cards.base#CARDS]]

---
## Dataview
```meta-bind-embed
[[MetaBind Main Navigation]]
```

```dataview
TABLE
file.ctime as "Date Created"
FROM "02 Cards"
SORT file.name DESC
```
